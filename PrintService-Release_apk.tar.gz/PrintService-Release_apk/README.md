# PrintService
Releases Print Service apk for Odoo POS Bluetooth/Built-in Printer app
